# -*- coding: utf-8 -*-

import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

_url = sys.argv[0]
_handle = int(sys.argv[1])

radioSTREAMS = {'Latvijas raidstacijas': [
						{'name':'Latvijas Radio 1','thumb':'https://freeliveradio.tk/audios/LR1.png','url':'http://lr2mp1.latvijasradio.lv:8012/;listen.mp3'},
                      	{'name':'Latvijas Radio 2','thumb':'https://freeliveradio.tk/audios/lr2.png','url':'http://lr2mp1.latvijasradio.lv:8002/;listen.mp3'},
                      	{'name':'Latvijas Radio 3 - Klasika','thumb':'https://freeliveradio.tk/audios/lr3.png','url':'http://lr3mp0.latvijasradio.lv:8004/;listen.mp3'},
					  	{'name':'Latvijas Radio 4 - Doma laukums','thumb':'https://freeliveradio.tk/audios/lr4.png','url':'http://lr4mp1.latvijasradio.lv:8020/;listen.mp3'},
						{'name':'Latvijas Radio 5 - pieci.lv','thumb':'https://freeliveradio.tk/audios/lr5.png','url':'http://ej.uz/piecilv_live'},
						{'name':'Latvijas Radio 6 - Radio NABA','thumb':'https://freeliveradio.tk/audios/naba1.png','url':'http://nabamp0.latvijasradio.lv:8016/;listen.mp3'},
						{'name':'Star FM','thumb':'https://freeliveradio.tk/audios/starfm.png','url':'http://starfm.live.advailo.com/audio/live/playlist.m3u8'},
						{'name':'EHR','thumb':'https://freeliveradio.tk/audios/ehr_lv.png','url':'http://stream.superfm.lv:8000/ehr.mp3'},
						{'name':'EHR Latviešu hīti','thumb':'https://freeliveradio.tk/audios/ehr_lh.png','url':'http://stream.superfm.lv:8000/Stream_02.mp3'},
						{'name':'EHR Dance','thumb':'https://freeliveradio.tk/audios/ehr_dance.png','url':'http://stream.superfm.lv:8000/Stream_17.mp3'},
						{'name':'EHR Fresh','thumb':'https://freeliveradio.tk/audios/ehr_fresh.png','url':'http://stream.superfm.lv:8000/Stream_05.mp3'},
						{'name':'EHR Darbam','thumb':'https://freeliveradio.tk/audios/ehr_work.png','url':'http://stream.superfm.lv:8000/Stream_23.mp3'},
						{'name':'EHR Русские Хиты','thumb':'https://freeliveradio.tk/audios/ehr_kh.png','url':'http://stream.superfm.lv:8000/khr.mp3'},
						{'name':'EHR Superhits','thumb':'https://freeliveradio.tk/audios/ehr_superhits.png','url':'http://stream.superfm.lv:8000/Stream_01.mp3'},
						{'name':'Radio TEV','thumb':'https://freeliveradio.tk/audios/rtev.jpg','url':'http://stream.radiotev.lv:8002/radiov'},
						{'name':'Kurzemes Radio','thumb':'https://freeliveradio.tk/audios/kurz_radio.png','url':'http://80.70.23.50:8000/;listen.mp3'},
						{'name':'Saldus Radio FM107.9','thumb':'https://freeliveradio.tk/audios/saldusradio.png','url':'http://80.70.17.194:8080/klausies'},
						{'name':'TopRadio','thumb':'https://freeliveradio.tk/audios/topradio.png','url':'http://195.13.200.164:8000/;listen.mp3'},
						{'name':'Talsu Radio','thumb':'https://freeliveradio.tk/audios/talsuradio.png','url':'http://radio.kuums.lv:5555/;'},
						{'name':'Pieci Hīti','thumb':'https://freeliveradio.tk/audios/pieci_hiti.png','url':'http://ej.uz/5hiti'},
						{'name':'Capital FM','thumb':'https://freeliveradio.tk/audios/capitalfm_lv.jpg','url':'http://radio2.capitalfm.lv:8000/;'},
						{'name':'Spin FM','thumb':'https://freeliveradio.tk/audios/spinfm.png','url':'http://80.232.162.149:8000/spin96mp3'},
						{'name':'Radio SWH','thumb':'https://freeliveradio.tk/audios/swh.jpg','url':'http://80.232.162.149:8000/swh96mp3'},
						{'name':'Radio Skonto','thumb':'https://freeliveradio.tk/audios/skonto.png','url':'http://skonto.ls.lv:8002/mp3'},
						{'name':'Radio 7','thumb':'https://freeliveradio.tk/audios/radio7.jpg','url':'http://stream.radio7.lv:8024/Radio7'},
						{'name':'Radio H2O','thumb':'https://freeliveradio.tk/audios/radio_h2o.png','url':'http://live.radioudens.com:8080/RadioH2O.mp3'},
						{'name':'Radio SWH Rock','thumb':'https://freeliveradio.tk/audios/swhrock.jpg','url':'http://80.232.162.149:8000/rock96mp3'},
						{'name':'ST Radio (demo - unofficial)','thumb':'https://freeliveradio.tk/audios/stradio_logo.png','url':'http://stradio.ddns.us:18301/stream.mp3'},
						{'name':'Radio Energy','thumb':'https://freeliveradio.tk/audios/energy.png','url':'http://radio1.radioenergy.lv:8000'},
						{'name':'Rietumu Radio','thumb':'https://freeliveradio.tk/audios/rr.png','url':'http://85.254.49.118:8000/stream/1/;listen.mp3'},
						{'name':'Pieci Latvieši','thumb':'https://freeliveradio.tk/audios/pieci_latv.png','url':'http://ej.uz/5latvieshi'},
						{'name':'Pieci Atklājumi','thumb':'https://freeliveradio.tk/audios/pieci_atklaj.png','url':'http://ej.uz/5atklajumi'},
						{'name':'MixFM','thumb':'https://freeliveradio.tk/audios/mixfm_lv.png','url':'http://radio.mixnews.lv/MixFM'},
						{'name':'Pieci Rīti','thumb':'https://freeliveradio.tk/audios/pieci_riti.png','url':'http://ej.uz/5riti'},
						{'name':'1.Biznesa Radio','thumb':'https://freeliveradio.tk/audios/1business.jpeg','url':'http://1br.lv:8000/1BusinessRadio'},
						{'name':'Retro FM','thumb':'https://freeliveradio.tk/audios/retrofm.png','url':'http://85.254.144.232:8000/256'},
						{'name':'Power FM','thumb':'https://freeliveradio.tk/audios/power.jpg','url':'http://lifemedia.cloud.makonix.com:8000/;listen.mp3'},
						{'name':'Radio Baltkom','thumb':'https://freeliveradio.tk/audios/radio_baltkom.jpg','url':'http://radio.mixnews.lv/baltkom'},
						{'name':'MixFM Dance','thumb':'https://freeliveradio.tk/audios/mixfmdance.jpg','url':'http://radio.mixnews.lv/995'},
						{'name':'JumorFM','thumb':'https://freeliveradio.tk/audios/jumorfm.jpg','url':'http://radio.mixnews.lv/jumorfm'},
						{'name':'Radio SWH Gold','thumb':'https://freeliveradio.tk/audios/swhgold.jpg','url':'http://80.232.162.149:8000/swhgold'},
						{'name':'Radio SWH+','thumb':'https://freeliveradio.tk/audios/swhplus.png','url':'http://80.232.162.149:8000/plus96mp3'},
						{'name':'Latvian Dance Music','thumb':'https://freeliveradio.tk/audios/ldm.jpg','url':'http://streaming.radionomy.com/LatvianDanceMusic'},
						{'name':'Radio A16','thumb':'https://freeliveradio.tk/audios/RadioA16.jpg','url':'http://radioa16lv.ddns.net:8000/;listen.mp3'}
                      ],
            'Ārzemju raidstacijas': [
						{'name':'Радио Unistar (Ukraina)','thumb':'https://freeliveradio.tk/audios/unistar_by.png','url':'http://unistar.by:8000/unistar-128kb'},
						{'name':'Capital FM (Kenija)','thumb':'https://freeliveradio.tk/audios/capitalfm_kenya.jpg','url':'rtsp://185.obj.netromedia.com/capitalfmflash/capitalfmflash'},
						{'name':'Sea FM (Somija)','thumb':'https://freeliveradio.tk/audios/Sea_FM.jpg','url':'http://s3.myradiostream.com:4976/;'},
						{'name':'MyHits (Igaunija)','thumb':'https://freeliveradio.tk/audios/myhits.jpg','url':'http://striiming.trio.ee/myhits.mp3'},
						{'name':'181.fm (ASV)','thumb':'https://freeliveradio.tk/audios/181.png','url':'http://181fm-edge1.cdnstream.com/181-power_128k.mp3'},
						{'name':'Mix FM (Ukraina)','thumb':'https://freeliveradio.tk/audios/mixfm_ukraine.png','url':'http://mixfm.com.ua/shoutcast/192/;stream.mp3'},
						{'name':'Rix FM (Zviedrija)','thumb':'https://freeliveradio.tk/audios/RIX-FM.png','url':'http://fm01-icecast.mtg-r.net/fm01_mp3?platform=web'},
						{'name':'РАДИО РУССКИЙ ХИТ (Krievija)','thumb':'https://freeliveradio.tk/audios/ruhit.png','url':'http://s7.imgradio.pro/RusHit48'},
						{'name':'Cork\'s Red FM (Lielbritānija)','thumb':'https://freeliveradio.tk/audios/redfm.png','url':'http://icy-e-03-boh.sharp-stream.com/redfm.mp3'},
						{'name':'RAI Radiodue (Itālija)','thumb':'https://freeliveradio.tk/audios/rairadio2.png','url':'http://icestreaming.rai.it/2.mp3'},
						{'name':'Big B Radio: JPOP (Japāna)','thumb':'https://freeliveradio.tk/audios/bigbradio_jp.png','url':'http://64.71.79.181:8018'},
						{'name':'EHR (Lietuva)','thumb':'https://freeliveradio.tk/audios/ehr_lt.png','url':'http://84.46.162.57:8000/ehr_m'},
						{'name':'Power Hit Radio (Lietuva)','thumb':'https://freeliveradio.tk/audios/pwhr.png','url':'http://82.135.147.245:8000/PHR'},
						{'name':'ANTENNE VORARLBERG (Austrija)','thumb':'https://freeliveradio.tk/audios/ant_vorarlb.png','url':'http://webradio.antennevorarlberg.at/live'},
						{'name':'Planet Radio (Vācija)','thumb':'https://freeliveradio.tk/audios/planet.png','url':'http://mp3.planetradio.de/planetradio/hqlivestream.mp3'},
						{'name':'Zip FM (Lietuva)','thumb':'https://freeliveradio.tk/audios/zipfm.png','url':'http://stream.zipfm.lt/zipfm128.mp3'},
						{'name':'Radiocentras (Lietuva)','thumb':'https://freeliveradio.tk/audios/rc.png','url':'http://stream.zipfm.lt/rc128.mp3'},
						{'name':'M-1 (Lietuva)','thumb':'https://freeliveradio.tk/audios/m­1.jpg','url':'http://stream.m­1.fm/m1/mp3'},
						{'name':'Radio 1 (Moldova)','thumb':'https://freeliveradio.tk/audios/fbrlogo.jpg','url':'http://pgtrk.ru:8000/stream'},
						{'name':'Blur FM (Argentīna)','thumb':'https://freeliveradio.tk/audios/blurfm.png','url':'http://64.34.175.149:8000/blurfm01'},
						{'name':'WELLE 1 (Austrija)','thumb':'https://freeliveradio.tk/audios/welle1.jpeg','url':'http://live.welle1.at:8128/;'},
						{'name':'Energy Wien (Austrija)','thumb':'https://freeliveradio.tk/audios/energy_wien.png','url':'http://stream1.energy.at:8000/vie'}
                     ]}
def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))

def get_categories():
    return radioSTREAMS.iterkeys()

def get_videos(category):
    return radioSTREAMS[category]

def list_categories():
    categories = get_categories()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({'thumb': radioSTREAMS[category][0]['thumb'],
                          'icon': radioSTREAMS[category][0]['thumb'],
                          'fanart': radioSTREAMS[category][0]['thumb']})
        list_item.setInfo('audio', {'title': category})
        url = get_url(action='listing', category=category)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def list_videos(category):
    videos = get_videos(category)
    for video in videos:
        list_item = xbmcgui.ListItem(label=video['name'])
        list_item.setInfo('audio', {'title': video['name']})
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', video=video['url'])
        is_folder = False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing':
            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(params['video'])
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])

"""
there will be new commands
{'name':'','thumb':'','url':''}
"""